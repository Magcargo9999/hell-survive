# 티어 재측정 제출 파일 — REPORT (v9.01)
생성 2026-10-25 18:34 KST · 게임 v9.01 (파일 해시 d78115b66913; git 없는 묶음이라 커밋 해시는 없음) · 봇 버전 ['0fb5bc92']
점수·티어는 계산하지 않았다(원본 + 요약 CSV + 카드 쌍비교만). 사용자 요청으로 카드 시너지 측정 도중 중단.

## 0. 먼저 알아둘 것
1. **카드 시너지(`syn:`)는 하한선(칸당 6시드)에 못 미쳤다** — 440칸이 시드 4·5개. 아래 §2 표 참고. 이 칸들은 `below_floor=Y`로 표시했고, 순수 효과를 단정하기엔 부족하다.
2. **재료만(`mat:`) 설정은 하나도 돌리지 못했다**(§7 줄이는 순서 ④). 그래서 "시너지 순수 효과(syn÷mat)·재료 자체의 힘(mat÷ctrl)"은 **분리 불가**, syn÷ctrl 쌍비교만 있다(`cards/paired_vs_ctrl.csv`).
3. **시너지 열림률 70%에 못 미치는 형태가 14개** (구조적, §3). 카드를 제안 밖에서 주지 않았다.
4. 측정 중 컨테이너 재시작·시간 제한으로 러너가 여러 번 끊겼으나 판 단위로 이어 돌렸다(끝난 판은 건너뜀). 판은 버리지 않았다.

## 1. 환경·변경점(하네스만 변경, 게임·봇 전투 로직은 그대로)
- 난이도 0단계(지하 1층), 보스 심장 없음, 스킨 OFF, 상점 강화 0, 쿠폰·챌린지 없음, 캐릭터·진화·숨은 보스 해금 전부 열림. 시드는 모든 캐릭터·설정에서 동일(1~N).
- 보스전 제한 **300초**(v8은 240), `boss_hp_pct_at`은 30~300초 30초 간격.
- **재현성**: 판마다 새 브라우저 컨텍스트(세이브 localStorage가 판 사이로 새던 문제) + **효과음 OFF**(`sfx()`가 `performance.now` 간격에 따라 `rand()`를 호출해 난수열이 달라지던 문제, 특히 구슬 쓰는 형태). 수정 뒤 병렬 1 vs 2 비교 5형태 전부 동일(`repro/`). 이 수정 전에는 문어·유령 기사에서 판이 달랐다.
- §5 사람형 시너지 정책 구현(`tools/tier3.py` CHOOSE): 우선순위 갈림길 > 진화 조건 > 목표 시너지 > 재료(낮은 쪽, Lv.3까지) > 전용 카드 > 공용·레벨업 > avoid, 슬롯 예약(증강 AUG_CAP−2종), 계획 전환(재료 0장이고 Lv.14 이상 또는 Lv.11 이후 5번 연속 제안에 재료 없음 → fallback, `plan_switch`·`offer_log` 기록). **Lv.11 이후만 센다** — 전용 카드는 진화(Lv.10) 뒤에야 나와서 1차 파일럿에서 Lv.6에 일찍 갈아타던 것을 고쳤다.

## 2. 계획 대비 실제 판 수
| 항목 | 계획(하한) | 실제 |
|---|---|---|
| A 보스전 (22종×6보스, 라운드 3) | 1,584 | **1584** (12시드 완료) |
| B 필드 (49형태, 라운드 3) | 588 | **588** (12판 완료) |
| E 성장 (최종 경로 22, 경로당 6판) | 132 | **132** |
| 카드 ctrl (14캐릭터×2보스×8시드) | 224 | **224** |
| 스킬카드 `@5` 6종 (12캐릭터×2보스×6시드) | 864 | **864** |
| 시너지 `syn:` (칸당 6시드) | 약 2,640 | **1874** (칸당 4·5시드) — **미달** |
| 재료만 `mat:` | 약 2,640 | **0** (미실시) |
| 증강 단독 `aug:`, 무작위 카드(D), 새 마왕 6종 | (P1/P2) | 미실시 |
라운드 4 이상(추가 시드)도 돌리지 못함. 게임 오류 기록 판: 2.

## 3. 시너지 열림률 (파일럿, 캐릭터×계획 8시드, `pilot_open_rate.csv`)
70% 미만(`structural_low_open`): wolf:holy 50%, snail:bomb 50%, archer:red 50%, archer:holy 38%, chimera:flame 12%, chimera 12%, chimera:dream 12%, lizard:guard 50%, twins 38%, wolf:fallen 62%, archer:skel 62%, lizard:rage 50%, lizard:water 50%, gun 0%.
- 키메라 3종은 전용 카드(airA/airB 등)가 Lv.10 진화 뒤에만 제안돼 구조적으로 낮다.
- `target_synergy_opened`·`synergy_level`·`plan_switch`·`offer_log`가 로그에 남아 있으니 원인 추적 가능.
- 본 측정 A(보스전)에서 plan_switch가 일어난 판 180/1584. 

## 4. 시드 편차 큰 셀 (보스전, 12시드, 깎은 체력% 표준편차 상위)
- lizard:guard × shk: sd 28.87
- wolf:crimson × shk: sd 28.14
- ghost:knight × monkey: sd 27.89
- lizard:rage × shk: sd 27.74
- wolf:holy × shk: sd 27.7
- archer:skel × monkey: sd 26.62
- lizard:guard × fw: sd 26.03
- chimera:flame × shk: sd 25.03
- archer:red × fw: sd 24.92
- wolf:twin × fw: sd 23.48
- wolf:fallen × shk: sd 23.29
- lizard:rage × skel: sd 22.5

## 5. 변경점 검증(§3 요청) — **제한적**
- 이 묶음에는 git 이력이 없어 `git diff 363b78f..HEAD`를 할 수 없었다. 그래서 커밋 제목 목록은 **검증하지 못했다**.
- 소스(`game_template.html`) 직접 확인한 것: 열충격(`shock`, 점화+빙결)·빙하(`glacier`)·달궈진 칼날(`forge`) 시너지 존재 · 유령 기사 루트(`kStep`·`kRip`·`kHead`, 듀라한 `lhead`) · 궁수 `snipe` 카드는 삭제되고 `range` 카드('저격 시선')로 합쳐짐 · 원숭이 지하 1층 십자 균열(`cross`) · 새 마왕·이독버섯 등 존재.
- 따라서 `build_plans.json`의 archer:holy `COND snipe`는 더 이상 카드가 아니다(봇이 `P.up.snipe`를 직접 세팅함).

## 6. 한계·주의
- 스킬카드는 Lv.5까지 올리는 동안 ctrl이 올리던 공용 스탯 카드를 못 올리므로, ctrl 대비 증감에 그 몫이 섞여 있다. ctrl이 97% 이상이면(쌍두 늑대·유령 등) 천장이라 비교 불가.
- 카드 분류: 공격 카드(thunder·blade·nova·aura) vs 적중 발동 상태이상(freeze·ignite) — `cards.json`의 `kind`.
- 영혼 조각은 봇이 입장료 통과용으로 올려 둠(전투 영향 없음). 이독버섯은 6종 계획(monkey·eye·skel·angel·shk·fw)에서 제외.

## 7. 파일
chars/raw_*.jsonl · chars/summary_*.csv · cards/raw_card.jsonl · cards/summary_card.csv(below_floor 표시) · cards/paired_vs_ctrl.csv · targets.json · cards.json · build_plans.json · pilot_open_rate.csv · repro/

## 8. 재현 명령
`python3 -m playwright install chromium` → `bash tools/tier4_run.sh`(이어 돌리기, 끝난 판은 건너뜀, `PAR=2`) → `python3 tools/tier4_pack.py`
